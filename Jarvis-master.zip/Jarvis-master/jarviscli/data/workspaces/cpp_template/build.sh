#Simple compile command to compile your c++ program
g++ -o out hello_world.cpp
