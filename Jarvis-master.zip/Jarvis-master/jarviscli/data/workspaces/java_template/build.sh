#Simple compile command to compile your Java program
javac HelloWorld.java
